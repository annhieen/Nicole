# Outcome Metric

## Purpose
Show a defensible result with context.

## Anatomy
- OUTCOME tag
- primary metric
- before/after context
- supporting note

Example:

5–7 min → <1 min

manual analysis → Rumi processing before Leasing review

## Rule
Never invent or overstate a metric.

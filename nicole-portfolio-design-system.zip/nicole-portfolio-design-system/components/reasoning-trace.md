# Reasoning Trace

## Purpose
Visualise how observations become decisions and systems.

## Variants

### Linear
Observation → Insight → Decision → System → Outcome

### Converging
Multiple signals → one decision

### Branching
Decision → alternatives/trade-offs → selected path

## States
- default
- active
- resolved
- human-check

## Visual rules
- 1px lines
- neutral by default
- amber only for active/selected node
- optional subtle glow
- every connection must have semantic meaning

## Don't
Use traces as decorative background.

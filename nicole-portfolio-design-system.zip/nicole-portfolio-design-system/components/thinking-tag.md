# Thinking Tag

Approved labels:

OBSERVATION
EVIDENCE
ASSUMPTION
CONSTRAINT
INSIGHT
ROOT PROBLEM
DECISION
TRADE-OFF
UNKNOWN
HUMAN CHECK
OUTCOME
SHIPPED
IN DISCOVERY

## Typography
IBM Plex Mono, 11–13px.

## Purpose
Explain why an artefact or decision is being shown.

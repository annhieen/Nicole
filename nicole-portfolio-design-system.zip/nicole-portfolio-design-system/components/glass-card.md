# Glass Card

## Purpose
Represent a system state, evidence layer or decision surface.

## Anatomy
- label
- title/content
- optional status chip
- optional node/connector

## Variants
- Evidence
- Unknown
- Trade-off
- Outcome
- System state

## Rule
Glass must have semantic purpose.

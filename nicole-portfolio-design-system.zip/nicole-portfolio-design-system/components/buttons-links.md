# Buttons & Links

## Primary
Ink background, white text, optional tiny amber signal.

## Secondary
Glass or outline.

## Text link
Understated underline or arrow.

## Focus
Visible focus ring. Do not rely on amber colour alone.

## Avoid
Large marketing-style CTA treatments unless required.

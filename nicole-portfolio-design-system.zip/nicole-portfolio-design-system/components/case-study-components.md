# Case Study Components

Reusable components:
- Snapshot
- Surface → Root Problem
- Discovery Evidence
- Key Insight
- Decision Card
- Reasoning Trace
- Trade-off State
- Unknown / Human Check
- System Diagram
- Outcome Metric
- Reflection Pull Quote

The system should not force every section into a card.

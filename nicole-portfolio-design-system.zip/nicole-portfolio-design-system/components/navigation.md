# Navigation

## Anatomy
- NP mark
- Work
- About
- Resume ↗
- Contact

## Active state
Thin amber underline or small amber node.

## Contact
May use dark Ink pill with tiny amber signal.

## Do not
- create large tabs
- use amber fill across the whole nav
- overcomplicate navigation

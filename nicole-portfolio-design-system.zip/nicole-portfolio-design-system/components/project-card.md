# Project Card

## Purpose
Introduce selected work without turning the homepage into four identical tiles.

## Anatomy
1. Project number
2. Title
3. One-line transformation
4. Status
5. Year
6. Representative artefact
7. Open affordance

## Status
- SHIPPED
- IN DISCOVERY

## Colour
Amber may highlight:
- project number
- hover state
- status detail

## Variants
- Dark artefact card (recommended for Rumi)
- Light editorial card
- Minimal discovery card

Cards may vary composition while retaining shared spacing/type rules.

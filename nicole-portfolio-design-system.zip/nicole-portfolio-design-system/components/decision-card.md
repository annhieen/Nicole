# Decision Card

## Purpose
Show judgement, not just implementation.

## Anatomy

DECISION / 02

Decision statement

WHY
Reasoning

TRADE-OFF
What was accepted or sacrificed

EVIDENCE
Optional supporting artefact

## Rule
A decision card should answer: why this approach, not another?

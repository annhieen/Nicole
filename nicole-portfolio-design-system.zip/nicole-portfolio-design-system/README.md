# Nicole Phan Portfolio Design System

A GitHub-ready design system and implementation reference for Nicole Phan's personal portfolio.

## Direction

**Silver Glass × Amber Signal**

The system is designed to position Nicole as someone who can understand ambiguity, connect customer/business/operations/data/technology perspectives, make clear decisions, and turn them into practical digital systems.

Core statement:

> **I make sense of messy problems.**

## How I Work

**Understand → Frame → Connect → Decide → Build → Learn ↺**

This is the portfolio's core working model.

## Repository structure

```text
foundations/  Visual foundations and brand principles
components/   Component anatomy, variants, states and usage rules
patterns/     Page-level composition and responsive patterns
content/      Voice, storytelling and project-status rules
tokens/       CSS and JSON design tokens
styles/       Starter implementation styles
examples/     Static HTML references
CLAUDE.md     Instructions for Claude/AI implementation
```

## Current portfolio projects

1. **Rumi — AI-assisted Enquiry Handling** — Shipped
2. **Website Redesign** — Shipped
3. **Tenant Portal Redesign on StarRez PortalX** — Shipped
4. **Operational Hub** — In Discovery / Planning

Operational Hub must never be represented as launched until its status changes.

## Recommended workflow

1. Read `CLAUDE.md`
2. Read `foundations/brand-principles.md`
3. Load `tokens/tokens.css`
4. Use component specifications in `components/`
5. Use `patterns/homepage.md` and `patterns/case-study.md`
6. Build project content without inventing facts or outcomes

## North Star

> Does this make Nicole look like someone who can understand complexity, make good decisions and build useful digital systems?

If not, simplify or remove it.

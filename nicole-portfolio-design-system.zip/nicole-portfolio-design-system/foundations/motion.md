# Motion

Motion reinforces:

**ambiguity → clarity**

## Approved behaviours

### Trace Reveal
Lines/nodes reveal progressively.

### Fade + Resolve
Muted information becomes legible when relevant.

### Layer Convergence
Multiple inputs converge into a decision.

### Amber Signal
Small amber activation on hover/focus/selection.

## Timing

180–450ms

Preferred easing:

`cubic-bezier(.22,1,.36,1)`

## Avoid

- decorative parallax
- floating blobs
- looping animations
- aggressive spring motion
- excessive route transitions

Always respect `prefers-reduced-motion`.

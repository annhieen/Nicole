# Brand Principles

## Brand idea

**Structured Curiosity**

Nicole's work begins with ambiguity and ends with a clearer working system.

The visual system should express:

**complexity → structure → decision → working system**

## Core statement

> **I make sense of messy problems.**

Supporting positioning:

> I connect customer needs, business realities and technology to turn ambiguity into practical digital products and systems.

## Brand tensions

### Cool systems × warm judgement
Silver/glass expresses structure, data and technology. Amber expresses decision and human judgement.

### Editorial × analytical
Layouts should have strong hierarchy and whitespace, but also diagrams, states, traces and evidence.

### Human × technical
The site should feel tech-savvy without becoming a developer demo or AI landing page.

## What the portfolio should prove

A recruiter should leave thinking:

> Nicole understands messy problems, connects perspectives that usually sit separately, makes good decisions and turns them into working digital systems.

## Design principles

1. Reasoning before decoration
2. Evidence over claims
3. Show judgement
4. Calm complexity
5. Tech without cliché
6. Preserve human control
7. Amber means something

# Spacing & Layout

## Grid

Desktop: 12 columns  
Tablet: 8 columns  
Mobile: 4 columns

Recommended desktop shell:

```css
max-width: 1480px;
margin: 0 auto;
padding-inline: 40px;
```

Column gap: `24px`

## Spacing scale

`4 / 8 / 12 / 16 / 20 / 24 / 32 / 40 / 48 / 64 / 80 / 96 / 120 / 160`

## Section rhythm

Major sections: 120–160px  
Internal section spacing: 24–64px

## Principle

The site should feel spacious and editorial, not dense like an operational dashboard.

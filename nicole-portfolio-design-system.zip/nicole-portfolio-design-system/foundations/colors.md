# Colour

## Core palette

| Token | Value |
|---|---|
| Canvas | `#F3F3F1` |
| Mist | `#E8EBEB` |
| Frost | `#F7F7F4` |
| Ink | `#14191C` |
| Slate | `#687075` |
| Muted | `#92999C` |
| Hairline | `rgba(20,25,28,0.10)` |

## Signal palette

| Token | Value |
|---|---|
| Signal Amber | `#D99A24` |
| Deep Amber | `#B97912` |
| Pale Amber | `#F3E4C2` |
| Amber Glow | `rgba(217,154,36,0.18)` |

## Semantic use

Amber is used for:
- active navigation
- decision markers
- selected paths
- key outcomes
- project numbering
- hover/focus moments
- current state in a reasoning trace

Amber is not:
- a hero background
- a large card fill
- a decorative gradient
- a secondary text colour everywhere

## Ratio

Aim roughly for:
- 70–75% light neutral
- 18–22% glass/white
- 5–7% dark ink
- 2–4% amber

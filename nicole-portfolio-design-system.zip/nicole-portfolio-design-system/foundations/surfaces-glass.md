# Surfaces & Glass

## Default Glass

```css
background: rgba(255,255,255,.46);
border: 1px solid rgba(255,255,255,.68);
backdrop-filter: blur(18px);
box-shadow:
  0 12px 36px rgba(25,35,40,.055),
  inset 0 1px 0 rgba(255,255,255,.72);
```

## Use glass for

- evidence
- system state
- reasoning module
- system diagram
- metadata cluster

## Do not use glass for

- every section
- every text block
- all project cards
- full-page wrappers

## Radius

- small: 6px
- card: 12px
- large glass: 18px
- pill: 999px

## Shadow

Shadows should be barely visible.

# Typography

## Primary

**Inter Tight**

Use for:
- hero
- headings
- body
- navigation
- project titles
- case-study narrative

## System

**IBM Plex Mono**

Use for:
- system labels
- metadata
- project numbers
- status
- technical annotations
- thinking tags

## Type scale

- Hero: `clamp(64px, 6.8vw, 112px)` / 600 / .92
- Case-study H1: 56–72px / 600
- H2: 36–48px / 550–600
- H3: 24–30px / 550–600
- Body Large: 20–22px / 1.45
- Body: 16–18px / 1.55
- Metadata: 11–13px / mono / tracking .06–.10em

## Rule

Typography should feel confident and precise, not loud.

Avoid:
- 900-weight hero type
- too many fonts
- decorative serif accents unless explicitly introduced later
- all-caps body copy

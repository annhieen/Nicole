# Project Status Rules

## Rumi
Status: **SHIPPED / LIVE**

## Website Redesign
Status: **SHIPPED**

## Tenant Portal Redesign
Status: **SHIPPED**

## Operational Hub
Status: **IN DISCOVERY / PLANNING**

Do not write:
- launched
- delivered
- implemented
- improved operations by X%
for Operational Hub unless that becomes true later.

If status changes, update this file first.

# Voice & Tone

## Voice

Clear  
Grounded  
Curious  
Structured  
Reflective  
Confident without overclaiming

## Preferred pattern

**What happened → what it meant → what I decided → why → what changed**

## Avoid

- passionate about
- leveraging cutting-edge AI
- innovation for innovation's sake
- generic transformation jargon
- inflated ownership claims
- invented outcomes

## Good
“The problem had shifted from collecting information to processing it.”

## Weak
“I leveraged cutting-edge AI to revolutionise the leasing process.”

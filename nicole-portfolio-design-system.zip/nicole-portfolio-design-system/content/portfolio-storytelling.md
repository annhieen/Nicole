# Portfolio Storytelling

The portfolio is not a CV with screenshots.

Its job is to expose Nicole's reasoning.

## Core narrative

Nicole:
1. notices what is happening
2. separates symptom from root problem
3. connects customer/business/operations/data/technology
4. decides what should change
5. turns it into a working solution
6. learns from the outcome and follows the next problem

## Signature storytelling devices

### Surface → Root
What it looked like vs what was actually happening.

### Decisions & Trade-offs
Why one approach was chosen.

### Reasoning Trace
How evidence became a system decision.

### Reflection
What changed in Nicole's thinking.

## Artefact rule
Every screenshot must answer a question.

No screenshot galleries without narrative purpose.

# System Diagram Patterns

## 1. Funnel
Use when candidate sets narrow.

Example:
41 → 15 → 6 → 3

## 2. Convergence
Use when multiple signals inform one decision.

## 3. Ownership flow
Use when a system output changes action ownership.

Example:
Best Match → Primary Team → Action Owner → Handoff → Secondary Activated

## 4. Human-in-the-loop
Use when AI and human responsibilities differ.

Example:
Rules → Rank → LLM → Human Review → Customer Message

## Visual rules
- use simple nodes
- no decorative complexity
- label transitions
- keep amber for selected/decision states

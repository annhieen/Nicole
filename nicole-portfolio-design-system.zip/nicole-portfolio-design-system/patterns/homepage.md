# Homepage Pattern

## Recommended sequence

1. Hero
2. Selected Work
3. How I Work
4. About Preview
5. Contact

## Hero

Left:
- discipline eyebrow
- headline
- support copy
- LinkedIn / Email / Resume

Right:
- simplified live-looking reasoning system
- Unknown
- Trade-off
- Outcome
- Rumi engine trace

## Selected Work

Order:
1. Rumi
2. Website Redesign
3. Tenant Portal Redesign
4. Operational Hub

## How I Work

Use:

**Understand → Frame → Connect → Decide → Build → Learn ↺**

Short definitions:

- Understand — Observe the real situation.
- Frame — Find the problem worth solving.
- Connect — See how the pieces affect one another.
- Decide — Evaluate options and trade-offs.
- Build — Turn the decision into something workable.
- Learn — Observe what changed and follow the next problem.

## Principle

Homepage should establish positioning in 30–60 seconds.

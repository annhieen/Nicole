# Case Study Pattern

High-level structure:

1. Snapshot
2. Situation
3. Problem
4. Discovery
5. Key Insights
6. Decisions & Trade-offs
7. Solution
8. Making It Real
9. Outcome
10. Reflection

## Signature patterns

### What it looked like → What was actually happening
Use early in the case study.

### Decisions & Trade-offs
This is the most important differentiated section.

### What changed in how I think
Reflection should show product/system growth, not generic lessons.

## Rumi emphasis
AI logic, rules vs judgement, uncertainty, human review, operational ownership.

## Website emphasis
Customer journey, IA, prioritisation, web delivery.

## PortalX emphasis
Self-service, SaaS constraints, optimisation.

## Operational Hub emphasis
Discovery, current-state complexity, operating model, product vision. No fake outcome.

# Responsive Pattern

## Desktop
Editorial asymmetry, 12 columns, multi-layer evidence compositions.

## Tablet
Simplify overlap; preserve hierarchy.

## Mobile
Use linear flow:

Eyebrow  
Headline  
Support copy  
Links  
Evidence stack  
Projects  
How I Work

Reasoning traces become vertical.

Avoid:
- essential horizontal scrolling
- tiny system labels
- overlapping glass cards that obscure content

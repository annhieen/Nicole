# CLAUDE.md — Portfolio Implementation Instructions

Treat this repository as the visual and interaction source of truth.

## 1. Core positioning

Nicole is not being positioned as a pure UX designer, pure developer, or traditional documentation-only Business Analyst.

The portfolio should communicate:

- systems thinking
- customer and business understanding
- structured problem framing
- decision quality
- digital/product delivery
- practical AI and workflow design
- ability to ship

Primary line:

> **I make sense of messy problems.**

## 2. Visual direction

Use **Silver Glass × Amber Signal**.

The site should feel:
- bright
- calm
- precise
- editorial
- technical
- contemporary
- lightly futuristic

Do not make it:
- blue SaaS
- cyberpunk
- neon AI
- beige lifestyle
- green sustainability
- playful scrapbook
- card-heavy enterprise dashboard

## 3. Colour rules

Use tokens from `tokens/tokens.css`.

Amber is semantic:
- active
- selected
- decision
- outcome
- meaningful signal

Do not spread amber decoratively across large surfaces.

Do not introduce a second brand accent colour unless explicitly approved.

## 4. Glass rules

Glass represents:
- evidence
- system states
- reasoning layers
- structured information

Do not use glass on every section.

Avoid excessive blur, glowing borders, or heavy shadows.

## 5. Typography

Use:
- Inter Tight for primary typography
- IBM Plex Mono for metadata/system language

Mono is reserved for semantic labels such as:

`OBSERVATION / 01`
`TRADE-OFF`
`SHIPPED · 2026`
`RUMI / LIVE SYSTEM`

Do not use mono for body paragraphs.

## 6. How I Work

Use:

**Understand → Frame → Connect → Decide → Build → Learn ↺**

Definitions:

- **Understand** — Observe the real situation using data, behaviour, stakeholder input and current process.
- **Frame** — Separate symptoms from the problem worth solving.
- **Connect** — See how customer, business, operations, data and technology affect one another.
- **Decide** — Evaluate options, constraints and trade-offs; determine what should change and what should not.
- **Build** — Turn the decision into requirements, workflows, product behaviour, UI and implementation.
- **Learn** — Observe what changed, identify the next bottleneck, and loop back into understanding.

Do not replace this with generic Design Thinking or Double Diamond language.

## 7. Portfolio storytelling

Case studies should prioritise:

1. What was happening?
2. What looked like the problem?
3. What was actually happening?
4. What evidence changed the understanding?
5. What decision was made?
6. What trade-off was accepted?
7. What was built?
8. What changed?
9. What was learned?

Prioritise decisions and reasoning over artefact galleries.

## 8. Project truth rules

Never invent:
- metrics
- responsibilities
- user research
- technical architecture
- adoption data
- project status
- implementation details

Known current statuses:
- Rumi: shipped/live
- Website Redesign: shipped
- Tenant Portal Redesign: shipped
- Operational Hub: in discovery/planning

Operational Hub must not be shown as delivered.

## 9. Rumi

Rumi is the flagship case study.

Important concepts:
- GA showed high website traffic but low meaningful general enquiries.
- Leasing feedback showed enquiries often lacked decision-ready information.
- Guided Enquiry was introduced to structure prospect preferences.
- Better structured enquiries created a new processing bottleneck.
- Rumi was built to automate repetitive analysis and assist leasing decisions.
- Matching separates feasibility, flexible fit, contextual ranking, AI reasoning and human review.
- Unknown information is surfaced for human confirmation.
- Leasing can include/exclude recommended rooms and generate/edit customer-facing replies.
- Human accountability remains with Leasing.
- Ownership/handoff rules prevent multiple teams following up the same prospect.

Do not reduce Rumi to “AI picks rooms.”

## 10. Responsive

Recompose rather than shrink.

Desktop:
- editorial 12-column layout
- asymmetric evidence compositions

Mobile:
- linear reading order
- reasoning trace becomes vertical
- no required horizontal scrolling
- preserve system labels and decision hierarchy

## 11. Motion

Use motion only to reinforce:
- trace reveal
- convergence
- resolution
- active signal

Keep motion subtle.

Respect `prefers-reduced-motion`.

## 12. Component behaviour

Build reusable primitives:
- `GlassCard`
- `ThinkingTag`
- `ReasoningTrace`
- `DecisionCard`
- `OutcomeMetric`
- `ProjectCard`
- `StatusChip`
- `CaseStudySection`

Follow component specs in `/components`.

## 13. Implementation priority

When a design choice conflicts with this repository:
1. project truth
2. accessibility
3. design system
4. visual novelty

Never sacrifice truth or usability for visual effect.
